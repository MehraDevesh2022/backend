const DB_LINK ="mongodb+srv://mehradevesh2022:bG43zxYFh5CjY4GW@cluster0.u9qjfd1.mongodb.net/";
const PORT = 8000;
const JWT_SECRET = "secret";

module.exports = {
  DB_LINK,
  PORT,
  JWT_SECRET,
};
